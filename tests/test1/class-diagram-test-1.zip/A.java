 

import java.util.Collection;

public class A extends B implements Y{

	private int x;
	 
	private int[] y;

	private int z;
	 
	public int a1(int x){
	}

	public float a2(float y, float z){
	}
	 
}

 
