 

public class B implements Runnable{
 
	private int a;
	
	private char b;

	public double c;

	public int b1(int x){
	}
	
	public float b2(float y){
	}
}
 
