 

public interface interfaceA1{

	public int x;

	public float y;

	public int interfaceMethod1(int x);

	public float interfaceMethod2(float y);

	
}